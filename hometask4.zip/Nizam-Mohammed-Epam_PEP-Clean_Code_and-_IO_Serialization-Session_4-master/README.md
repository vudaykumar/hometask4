# Nizam-Mohammed-Epam_PEP-Clean_Code_and-_IO_Serialization-Session_4

[Goto JAVA files](https://github.com/nizam19/Nizam-Mohammed-Epam_PEP-Clean_Code_and-_IO_Serialization-Session_4/tree/master/com.epam.clean/src/main/java/com/epam/clean)
